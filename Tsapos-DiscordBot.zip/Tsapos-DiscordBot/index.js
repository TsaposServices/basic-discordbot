const Discord = require('discord.js');
const {MessageEmbed} = require('discord.js');
const moment = require('moment')
const bot = new Discord.Client();

const PREFIX = '!'; // Vale to PREFIX pou thes na exei to bot sou

const token = 'Your Token'; // Kane ena Discord Bot Account apo edo kai vale to token (https://discord.com/developers/applications/)

bot.on('ready', () =>{ 
    console.log('Tsapos-DiscordBot is now online! (Author: Tsapos)');
    bot.user.setPresence({
        activity: {
            name: 'The Server',
            type: 'WATCHING'
        },
    })
})

bot.on('message', message =>{
    if(message.content === "!onduty") {
        var d = moment().format('h:mm:ss a');
        const onduty = new MessageEmbed()
        .setColor(0xFF0000)
        .setFooter('Discord Basic Bot by Tsapos')
        .setDescription(`**Ο ${message.author} μπηκε on duty στις: `
        +  `${d}**`)
        message.channel.send(onduty);
        
    }
})

bot.on('message', message =>{
    if(message.content === "!offduty") {
        var d = moment().format('h:mm:ss a');
        const offduty = new MessageEmbed()
        .setColor(0xFF0000)
        .setFooter('Discord Basic Bot by Tsapos')
        .setDescription(`**Ο ${message.author} μπηκε off duty στις: `
        +  `${d}**`)
        message.channel.send(offduty);
        
    }
})

bot.on('message', message =>{
    if(message.content === "!donates") {
        const donates = new MessageEmbed()
        .setColor(0xFF0000)
        .setTitle('Donate Packs')
        .addField('Donate Pack Name', 'Ti tha periexei to pack')
        .addField('Donate Pack Name', 'Ti tha periexei to pack')
        .addField('Donate Pack Name', 'Ti tha periexei to pack')
        .addField('Donate Pack Name', 'Ti tha periexei to pack')
        .addField('Donate Pack Name', 'Ti tha periexei to pack')
        .addField('Donate Pack Name', 'Ti tha periexei to pack')
        .setFooter('Discord Basic Bot by Tsapos')
        .setThumbnail('https://cdn.discordapp.com/attachments/806198079689982022/821002646567518228/services.png')
        .setTimestamp()
        message.channel.send(donates);
        
    }
})

bot.on('message', message =>{
    if(message.content === "!rules") {
        const rules = new MessageEmbed()
        .setColor(0xFF0000)
        .setTitle('Server Rules')
        .addField('Rule Name', 'epekshghsh tou rule')
        .addField('Rule Name', 'epekshghsh tou rule')
        .addField('Rule Name', 'epekshghsh tou rule')
        .addField('Rule Name', 'epekshghsh tou rule')
        .addField('Rule Name', 'epekshghsh tou rule')
        .addField('Rule Name', 'epekshghsh tou rule')
        .addField('Rule Name', 'epekshghsh tou rule')
        .addField('Rule Name', 'epekshghsh tou rule')
        .setFooter('Discord Basic Bot by Tsapos')
        .setThumbnail('https://cdn.discordapp.com/attachments/806198079689982022/821002646567518228/services.png')
        .setTimestamp()
        message.channel.send(rules);
        
    }
})

bot.on("message", msg => {
    if (msg.content.toLowerCase().startsWith('https://')) {
        async function clear() {
            msg.delete();
        }
        clear();
    }
});


bot.login(token)

// Basic Discord Bot By Tsapos ©
